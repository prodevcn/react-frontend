import React from 'react';

export class Loading extends React.Component {
  render() {
    return (
      <i className='fa fa-spinner fa-spin' />
    );
  }
}
